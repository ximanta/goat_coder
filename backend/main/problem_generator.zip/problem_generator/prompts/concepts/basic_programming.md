Choose from these beginner-friendly problem types:
1. String Manipulation
   - Reverse a string
   - Count specific characters
   - Convert case (upper/lower)

2. Simple Array Operations
   - Find maximum/minimum
   - Count elements matching condition
   - Find first/last occurrence

3. Number Patterns
   - Check even/odd patterns
   - Count digits
   - Check number properties

DO NOT generate:
- Calculator problems
- Basic arithmetic operations
- Sum of numbers problems 