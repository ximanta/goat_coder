For EASY difficulty level, ensure:

1. Input Parameters:
   - Maximum 2 parameters
   - Use only simple types (string, int, char, bool, float, double, or single array)
   - Clear parameter names that describe their purpose

2. Problem Scope:
   - Single operation or transformation
   - No nested loops required
   - No complex conditions
   - No Dict types
   - Linear solution possible

3. Test Cases:
   - 2-3 simple test cases
