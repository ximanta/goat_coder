Use these real-world contexts:
- Gaming scores and achievements
- Social media post analysis
- School grade calculations
- Weather data processing
- Shopping and inventory
- Music playlist management
- Text message analysis
- Sports statistics 